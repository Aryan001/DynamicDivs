var app = angular.module('drag', ['ngMaterial', 'ngMessages',"ngRoute"]);
app.controller('Ctrl',function($scope){
  $scope.array=[];
  // console.log('inside');
  $scope.remove = function(event){
  // console.log(event);
  // console.log(event.currentTarget.parentNode.parentNode.attributes.id.value);
  $scope.array.push(event.currentTarget.parentNode.parentNode.attributes.id.value);
  var el = document.querySelector("#"+event.currentTarget.parentNode.parentNode.attributes.id.value);
  angular.element(el).addClass('remove')
  document.querySelector("#"+event.currentTarget.parentNode.parentNode.attributes.id.value).removeAttribute("hidden");
  console.log(el);
}

var a=[0,0,0,0],i;
$scope.resize = function(event,i){
  // console.log(event.currentTarget.attributes.id.value);
// console.log(event.currentTarget.attributes.class.value);
console.log(event.currentTarget.parentNode.parentNode.attributes.id.value);
if(a[i]==0)
{
  document.getElementById(event.currentTarget.attributes.id.value).className="glyphicon glyphicon-resize-small";
  document.getElementById(event.currentTarget.parentNode.parentNode.attributes.id.value).style.width="1330px";
  document.getElementById(event.srcElement.parentElement.nextElementSibling.attributes.id.value).style.width="1300px";
  a[i]=1;
}
else {
  document.getElementById(event.currentTarget.attributes.id.value).className="glyphicon glyphicon-resize-full";
  document.getElementById(event.currentTarget.parentNode.parentNode.attributes.id.value).style.width="45%";
  document.getElementById(event.srcElement.parentElement.nextElementSibling.attributes.id.value).style.width="550px";
  a[i]=0;
}
}


$scope.setVisibility=function()
{
  var a=document.querySelectorAll("[hidden]");
  console.log(a);
  for(var k=0;k<a.length;k++){
    console.log(a[k]);
    angular.element(a[k]).addClass('remove')
  }
  for(i=0;i<$scope.array.length;i++){
    var el = document.querySelector("#"+$scope.array[i]);
    angular.element(el).removeClass('remove')
  }
}

$scope.home=function()
{
    $scope.array=[];
  var a=document.querySelectorAll(".draggable");
  console.log(a);
  angular.element(a).removeClass('remove')
}


$scope.onegraph=function(event)
{
  for(i=0;i<event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length;i++)
  {
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value);
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value);
    var a=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
    document.getElementById(a).style.width="1330px";
    var b=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
    document.getElementById(b).style.width="1330px";
  }
}

$scope.twograph=function()
{
  for(i=0;i<event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length;i++)
  {
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value);
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value);
    var a=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
    document.getElementById(a).style.width="45%";
    var b=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
    document.getElementById(b).style.width="600px";
  }
}

$scope.threegraph=function()
{
  for(i=0;i<event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children.length;i++)
  {
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value);
    console.log(event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value);
    var a=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].attributes.id.value;
    document.getElementById(a).style.width="30%";
    var b=event.srcElement.parentElement.parentElement.parentElement.nextElementSibling.children[i].children[1].attributes.id.value;
    document.getElementById(b).style.width="380px";
  }
}


$scope.divs=[];
var j=4;
$scope.addDiv=function()
{
  j++;
  $scope.divs.push(j);
  console.log($scope.divs);
  a.push(0);
}

});


$( function() {
    $( "#sortable" ).sortable();
} );

$( function() {
    $( ".dynamic" ).sortable();
} );
